/**
 * Provides Bluetooth transferring services.
 * Containg a Bluetooth server and a Bluetooth client available
 * through the provider.
 */
package project.cs.lisa.bluetooth;