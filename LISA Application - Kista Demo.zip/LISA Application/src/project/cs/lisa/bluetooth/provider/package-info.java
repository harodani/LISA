/**
 * Provides Bluetooth provider that acts as a client.
 */
package project.cs.lisa.bluetooth.provider;