/**
 * Provides functionalities for retrieving Byte Objects from 
 * locators through different kind of services.
 */
package project.cs.lisa.transferdispatcher;