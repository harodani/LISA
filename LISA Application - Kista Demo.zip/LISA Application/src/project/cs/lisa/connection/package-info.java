/**
 * Sprint 1 Demo Application.
 * Sends a GET requests and displays the result
 */
package project.cs.lisa.connection;